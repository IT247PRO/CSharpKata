﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RedPencil.Business
{
    public class RedPencil
    {


        public double OriginalPrice;
        public double SalePrice;
        public DateTime LastUpdateDate;
        public DateTime SalePriceStartDate;

        public RedPencil(double price, DateTime startDate)
        {
            this.OriginalPrice = price;
            this.SalePriceStartDate = startDate;
        }

        public double GetPrice()
        {
            if (PromotionIsOver())
            {
                EndPromotion(SalePrice);
            }
            return OriginalPrice;
        }

        public bool PromotionIsOver()
        {
            return SalePriceStartDate > DateTime.Now.AddDays(30);
        }

        public void SetPrice(double newPrice, DateTime currentDate)
        {          

            GetPrice();
            if (PriceChangeIsWithinPromotionBoundaries(newPrice))
            {
                if (SalePrice > 0)
                    SalePrice = newPrice;

                else if (PriceHasBeenStable(currentDate))
                {
                    SalePriceStartDate = currentDate;
                    SalePrice = newPrice;
                }
                else
                    OriginalPrice = newPrice;

            }
            else
                EndPromotion(newPrice);

            LastUpdateDate = currentDate;
        }

        public bool PriceChangeIsWithinPromotionBoundaries(double newPrice)
        {
            var changePercentage = (OriginalPrice - newPrice) / OriginalPrice;
            return changePercentage >= 0.05 && changePercentage <= 0.30;
        }

        public bool PriceHasBeenStable(DateTime currentDate)
        {
            return currentDate <= DateTime.Now.AddDays(29);
        }

        private void EndPromotion(double newPrice)
        {
            OriginalPrice = newPrice;
            SalePrice = 0;
        }

    }
}
