﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace RedPencil.Business.Test
{
    [TestClass]
    public class RedPencelTest
    {
        RedPencil redPencil; 
        public RedPencelTest()
        {
            redPencil = new RedPencil(100, DateTime.Now);
            redPencil.SetPrice(78, DateTime.Now);
        }

        [TestMethod]
        public void SalePriceIs5Percent()
        {
            Assert.AreEqual(true, redPencil.PriceChangeIsWithinPromotionBoundaries(95));
        }
        [TestMethod]
        public void SalePriceIs30Percent()
        {
            Assert.AreEqual(true, redPencil.PriceChangeIsWithinPromotionBoundaries(70));
        }

        [TestMethod]
        public void SalePriceIsLessThan5Percent()
        {
            Assert.AreEqual(false, redPencil.PriceChangeIsWithinPromotionBoundaries(96));
        }
        [TestMethod]
        public void SalePriceIsGreaterThan30Percent()
        {
            Assert.AreEqual(false, redPencil.PriceChangeIsWithinPromotionBoundaries(69));
        }

        [TestMethod]
        public void SalePriceIsWithIn30Days()
        {
            Assert.AreEqual(true, redPencil.PriceHasBeenStable(DateTime.Now.AddDays(29)));
        }

        [TestMethod]
        public void SalePriceIsOver30Days()
        {
            Assert.AreEqual(false, redPencil.PriceHasBeenStable(DateTime.Now.AddDays(31)));
        }

        [TestMethod]
        public void SalePriceToTotalDiscountGreaterThan30PercentEndsPromotion()
        {
            var pencil = new RedPencil(100, DateTime.Now);
            //SET SALE
            redPencil.SetPrice(70, DateTime.Now.AddDays(-20));
            var saleStartDateAt70Percent = pencil.LastUpdateDate;
            // SET SALE PRICE Decreased           
            redPencil.SetPrice(69, DateTime.Now);
            var saleStartDateAt69Percent = pencil.LastUpdateDate;
            //END Promotion
            Assert.AreEqual(saleStartDateAt70Percent, saleStartDateAt69Percent);
        }
        // WRONG Result 
    }
}
