﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace StringCalculator.Test
{
    [TestClass]
    public class CalculatorTest
    {
        [TestMethod]
        public void EmptyStringReturnZero()
        {
            string numbers = "";

            Assert.AreEqual(0, new Calculator().Add(numbers));

        }

        [TestMethod]
        public void AddOneNumberOnly()
        {
            string numbers = "1";

            Assert.AreEqual(1, new Calculator().Add(numbers));
        }

        [TestMethod]
        public void AddNumbers()
        {
            string numbers = "3, 0, 3, 5";

            Assert.AreEqual(11, new Calculator().Add(numbers));
        }

        [TestMethod]
        public void NewLineInNumber()
        {
            string numbers = "5\n0, 5";

            Assert.AreEqual(10, new Calculator().Add(numbers));
        }

        [TestMethod]
        public void DelimiterUpdate()
        {
            string numbers = "//;\n1;2";

            Assert.AreEqual(3, new Calculator().Add(numbers));
        }

        [TestMethod]
        public void NegativeNumbersException()
        {
            string numbers = "1,-2";
            try
            {
                new Calculator().Add(numbers);
                Assert.Fail("Fail Test");
            }
            catch (ApplicationException ex)
            {
                Assert.AreEqual("Negatives: -2", ex.Message);
            }
        }

        [TestMethod]
        public void NegativeNumbersExceptionWithAllNagitive()
        {
            string numbers = "1,-2,-3";
            try
            {
                new Calculator().Add(numbers);
                Assert.Fail("Fail Test");
            }
            catch (ApplicationException ex)
            {
                Assert.AreEqual("Negatives: -2, -3", ex.Message);
            }
        }

        [TestMethod]
        public void IgnoreNumbersBigThan1000()
        {
            string numbers = "1,1001";

            Assert.AreEqual(1, new Calculator().Add(numbers));
        }

        [TestMethod]
        public void DelimiterCanBeAnyLength()
        {
            string numbers = "//[***]\n1***2***3";

            Assert.AreEqual(6, new Calculator().Add(numbers));
        }
    }
}
