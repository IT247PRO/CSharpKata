﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace StringCalculator
{
    public class Calculator
    {
        protected string StringWithNumbers { get; set; }
        protected string[] StringNumbersArray { get; set; }
        
        private void SplitNumberStringInArray()
        {
            string[] Delimiters = ConfigureDelimiters();

            Regex f = new Regex(@"(\d+)");

            StringNumbersArray = f.Split(StringWithNumbers);

            StringNumbersArray = StringWithNumbers.Split(Delimiters, StringSplitOptions.RemoveEmptyEntries);
        }

        private string[] ConfigureDelimiters()
        {
            string[] separators;
            if (StringWithNumbers.Contains("//"))
            {

                if (StringWithNumbers.IndexOf('[') == 2)
                {
                    int i = 0;
                    separators = new string[GetSeparatorsNumber(StringWithNumbers.Substring(2, StringWithNumbers.IndexOf('\n') - 2))];
                    var sep = StringWithNumbers.Substring(2, StringWithNumbers.IndexOf('\n') - 2).Split('[', ']').Where(x => x != string.Empty);
                    foreach (var separator in sep)
                    {
                        separators[i] = separator;
                        i++;
                    }
                }
                else
                {
                    separators = new string[1];
                    separators[0] = StringWithNumbers.Substring(2, StringWithNumbers.IndexOf('\n') - 2);
                }

                StringWithNumbers = StringWithNumbers.Substring(StringWithNumbers.IndexOf('\n'));
            }
            else
            {
                separators = new string[2];
                separators[0] = ",";
                separators[1] = "\n";
            }
            return separators;
        }

        protected void CheckIfExistNegativeNumbers()
        {
            var numbersNegative = StringNumbersArray.Where(x => int.Parse(x) < 0);
            if (numbersNegative.Any())
                throw new ApplicationException("Negatives: " + string.Join(", ", numbersNegative.ToArray()));

        }
        public int Add(string numbers)
        {
            this.StringWithNumbers = numbers;

            if (IsEmptyNumbers())
                return 0;

            SplitNumberStringInArray();

            CheckIfExistNegativeNumbers();

            RemoveNumbersBigThan1000();

            return StringNumbersArray.Sum(x => int.Parse(x));

        }
        protected void RemoveNumbersBigThan1000()
        {
            var num = StringNumbersArray.ToList();
            num.RemoveAll(x => int.Parse(x) > 1000);
            StringNumbersArray = num.ToArray();
        }
        private int GetSeparatorsNumber(string value)
        {
            return value.Split('[', ']').Count(x => x != string.Empty);
        }
        private bool IsEmptyNumbers()
        {
            return string.IsNullOrEmpty(StringWithNumbers);
        }

    }
}
